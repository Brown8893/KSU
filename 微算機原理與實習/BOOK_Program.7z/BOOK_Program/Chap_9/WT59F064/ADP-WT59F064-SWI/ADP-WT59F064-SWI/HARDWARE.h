#ifndef     _HARDWARE_H_
#define     _HARDWARE_H_

#define GPIO_PA	0x001F6800
#define GPIO_PB	0x001F6880 
#define GPIO_PC 0x001F6900 
#define GPIO_PD 0x001F6980 
#define GPIO_PE	0x001F6A00


#define GPIO_ACT_PA	*((unsigned int *)(GPIO_PA+0x00))
#define GPIO_OEN_PA	*((unsigned int *)(GPIO_PA+0x04))
#define GPIO_OMOD_PA	*((unsigned int *)(GPIO_PA+0x08))
#define PAD_PA		*((unsigned int *)(GPIO_PA+0x0C))
#define	GPIO_DAT_PA	*((unsigned int *)(GPIO_PA+0x10))
#define GPIO_REN_PA	*((unsigned int *)(GPIO_PA+0x14))
#define GPIO_RS_PA	*((unsigned int *)(GPIO_PA+0x18))
#define GPIO_BR_PA	*((unsigned int *)(GPIO_PA+0x1C))
#define GPIO_BS_PA	*((unsigned int *)(GPIO_PA+0x20))


#define GPIO_ACT_PB	*((unsigned int *)(GPIO_PB+0x0))
#define GPIO_OEN_PB	*((unsigned int *)(GPIO_PB+0x04))
#define GPIO_OMOD_PB	*((unsigned int *)(GPIO_PB+0x08))
#define PAD_PB		*((unsigned int *)(GPIO_PB+0x0C))
#define GPIO_DAT_PB	*((unsigned int *)(GPIO_PB+0x10))
#define GPIO_REN_PB	*((unsigned int *)(GPIO_PB+0x14))
#define GPIO_RS_PB	*((unsigned int *)(GPIO_PB+0x18))
#define GPIO_BR_PB	*((unsigned int *)(GPIO_PB+0x1C))
#define GPIO_BS_PB	*((unsigned int *)(GPIO_PB+0x20))


#define GPIO_ACT_PC	*((unsigned int *)(GPIO_PC+0x00))
#define GPIO_OEN_PC	*((unsigned int *)(GPIO_PC+0x04))
#define GPIO_OMOD_PC	*((unsigned int *)(GPIO_PC+0x08))
#define PAD_PC		*((unsigned int *)(GPIO_PC+0x0C))
#define GPIO_DAT_PC	*((unsigned int *)(GPIO_PC+0x10))
#define GPIO_REN_PC	*((unsigned int *)(GPIO_PC+0x14))
#define GPIO_RS_PC	*((unsigned int *)(GPIO_PC+0x18))
#define GPIO_BR_PC	*((unsigned int *)(GPIO_PC+0x1C))
#define GPIO_BS_PC	*((unsigned int *)(GPIO_PC+0x20))


#define GPIO_ACT_PD	*((unsigned int *)(GPIO_PD+0x0))
#define GPIO_OEN_PD	*((unsigned int *)(GPIO_PD+0x04))
#define GPIO_OMOD_PD	*((unsigned int *)(GPIO_PD+0x08))
#define PAD_PD		*((unsigned int *)(GPIO_PD+0x0C))
#define GPIO_DAT_PD	*((unsigned int *)(GPIO_PD+0x10))
#define GPIO_REN_PD	*((unsigned int *)(GPIO_PD+0x14))
#define GPIO_RS_PD	*((unsigned int *)(GPIO_PD+0x18))
#define GPIO_BR_PD	*((unsigned int *)(GPIO_PD+0x1C))
#define GPIO_BS_PD	*((unsigned int *)(GPIO_PD+0x20))

#define GPIO_ACT_PE 	*((unsigned int *)(GPIO_PE+0x00)) //GPIO mode
#define GPIO_OEN_PE	*((unsigned int *)(GPIO_PE+0x04)) //output enable
#define GPIO_OMOD_PE	*((unsigned int *)(GPIO_PE+0x08)) //output mode
#define PAD_PE		*((unsigned int *)(GPIO_PE+0x0C)) //Data in
#define GPIO_DAT_PE	*((unsigned int *)(GPIO_PE+0x10)) //Data out
#define GPIO_REN_PE	*((unsigned int *)(GPIO_PE+0x14)) //resistor enable
#define GPIO_RS_PE	*((unsigned int *)(GPIO_PE+0x18)) //pull high or down
#define GPIO_BR_PE	*((unsigned int *)(GPIO_PE+0x1C)) //Bit clear
#define GPIO_BS_PE	*((unsigned int *)(GPIO_PE+0x20)) //Bit setting


#define PWM	0x001F6000

#define PWM_EN 		*((unsigned int *)(PWM+0x00)) //pwn enable
#define PWM_BAS_CLK	*((unsigned int *)(PWM+0x04)) //basic clock
#define PWM_CLK0	*((unsigned int *)(PWM+0x08)) //clk no.
#define PWM_CLK1	*((unsigned int *)(PWM+0x0C))
#define PWM_CLK2	*((unsigned int *)(PWM+0x10))
#define PWM_CLK3	*((unsigned int *)(PWM+0x14))
#define PWM0		*((unsigned int *)(PWM+0x18)) //duty cycle
#define PWM1		*((unsigned int *)(PWM+0x1C))
#define PWM2		*((unsigned int *)(PWM+0x20))
#define PWM3		*((unsigned int *)(PWM+0x24))
#define PERIOD_0	*((unsigned int *)(PWM+0x28)) //period clk o.
#define PERIOD_1	*((unsigned int *)(PWM+0x2C))
#define PERIOD_2	*((unsigned int *)(PWM+0x30))
#define PERIOD_3	*((unsigned int *)(PWM+0x34))

#define RTC	0x00201000

#define RTC_SEC		*((unsigned int *)(RTC+0x00))
#define RTC_MIN 	*((unsigned int *)(RTC+0x04))
#define RTC_HOUR 	*((unsigned int *)(RTC+0x08))
#define RTC_DAY 	*((unsigned int *)(RTC+0x0C))
#define RTC_WEEK 	*((unsigned int *)(RTC+0x10))
#define RTC_MONTH 	*((unsigned int *)(RTC+0x14))
#define RTC_YEAR 	*((unsigned int *)(RTC+0x18))
#define RTC_BAKUP1	*((unsigned int *)(RTC+0x20))
#define RTC_BAKUP2 	*((unsigned int *)(RTC+0x24))
#define RTC_BAKUP3 	*((unsigned int *)(RTC+0x28))
#define RTC_BAKUP4 	*((unsigned int *)(RTC+0x2C))
#define RTC_AMP 		*((unsigned int *)(RTC+0x30))
#define RTC_CAL 		*((unsigned int *)(RTC+0x34)) //Calibration bits
#define RTC_CTR 	*((unsigned int *)(RTC+0x38))//control reg. power down 32.768Khz osc.
#define RTC_Bias	*((unsigned int *)(RTC+0x3C)) //Bias resistor selection

#define I2C	0x00205800 //I2C�A�b�ϥΤ�U��70���A�P�d�ҳ]�w���P�C

#define MI2C_EN		*((unsigned int *)(I2C+0x00))
#define	MI2C_RDY	*((unsigned int *)(I2C+0x04))
#define	MI2C_DSLV	*((unsigned int *)(I2C+0x08))
#define	MI2C_DTX	*((unsigned int *)(I2C+0x0C))
#define	MI2C_DRX	*((unsigned int *)(I2C+0x10))
#define	MI2C_SADR	*((unsigned int *)(I2C+0x14))
#define	MI2C_DMAEN	*((unsigned int *)(I2C+0x18))

#define IR	0x00201800 //IR�A�b�ϥΤ�U��74���A���]�wName�Ĥ@�ӡC

#define IR_EN		*((unsigned int *)(IR+0x00))
#define	IR_HL		*((unsigned int *)(IR+0x04))
#define	IR_CNT		*((unsigned int *)(IR+0x08))
#define	IR_FILTER	*((unsigned int *)(IR+0x0C))

#define UART0   0x00203400 //UART�A�b�ϥΤ�U��53���A���]�wName�Ĥ@�ӡC
#define UART1   0x00203800 //UART�A�b�ϥΤ�U��53���A���]�wName�Ĥ@�ӡC
#define UART2   0x00203C00 //UART�A�b�ϥΤ�U��53���A���]�wName�Ĥ@�ӡC
#define UART3   0x00204000 //UART�A�b�ϥΤ�U��53���A���]�wName�Ĥ@�ӡC

#define UART0_LCR	*((unsigned int *)(UART0+0x00)) //line control
#define	UART0_IER	*((unsigned int *)(UART0+0x04)) //Interrupt enable
#define	UART0_LSR	*((unsigned int *)(UART0+0x08)) //Status reg.
#define	UART0_THR	*((unsigned int *)(UART0+0x0C)) // transmitting reg.
#define	UART0_RBR	*((unsigned int *)(UART0+0x10)) //receiving reg.
#define	UART0_BAUD	*((unsigned int *)(UART0+0x14)) //baud rate reg.
#define	UART0_LBRK	*((unsigned int *)(UART0+0x18)) //break reg.

#define UART1_LCR	*((unsigned int *)(UART1+0x00)) //line control
#define	UART1_IER	*((unsigned int *)(UART1+0x04)) //Interrupt enable
#define	UART1_LSR	*((unsigned int *)(UART1+0x08)) //Status reg.
#define	UART1_THR	*((unsigned int *)(UART1+0x0C)) // transmitting reg.
#define	UART1_RBR	*((unsigned int *)(UART1+0x10)) //receiving reg.
#define	UART1_BAUD	*((unsigned int *)(UART1+0x14)) //baud rate reg.
#define	UART1_LBRK	*((unsigned int *)(UART1+0x18)) //break reg.

#define UART2_LCR	*((unsigned int *)(UART2+0x00)) //line control
#define	UART2_IER	*((unsigned int *)(UART2+0x04)) //Interrupt enable
#define	UART2_LSR	*((unsigned int *)(UART2+0x08)) //Status reg.
#define	UART2_THR	*((unsigned int *)(UART2+0x0C)) // transmitting reg.
#define	UART2_RBR	*((unsigned int *)(UART2+0x10)) //receiving reg.
#define	UART2_BAUD	*((unsigned int *)(UART2+0x14)) //baud rate reg.
#define	UART2_LBRK	*((unsigned int *)(UART2+0x18)) //break reg.

#define UART3_LCR	*((unsigned int *)(UART3+0x00))
#define	UART3_IER	*((unsigned int *)(UART3+0x04))
#define	UART3_LSR	*((unsigned int *)(UART3+0x08))
#define	UART3_THR	*((unsigned int *)(UART3+0x0C))
#define	UART3_RBR	*((unsigned int *)(UART3+0x10))
#define	UART3_BAUD	*((unsigned int *)(UART3+0x14))
#define	UART3_LBRK	*((unsigned int *)(UART3+0x18)


#define TIMER0   0x00201C00 //TIMER0�A�b�ϥΤ�U��68���A���]�wName�Ĥ@�ӡC
#define TIMER1   0x00202000 //TIMER1�A�b�ϥΤ�U��68���A���]�wName�Ĥ@�ӡC
#define TIMER2   0x00202400 //TIMER2�A�b�ϥΤ�U��68���A���]�wName�Ĥ@�ӡC
#define TIMER3   0x00202800 //TIMER3�A�b�ϥΤ�U��68���A���]�wName�Ĥ@�ӡC
#define TIMER4   0x00202C00 //TIMER4�A�b�ϥΤ�U��68���A���]�wName�Ĥ@�ӡC
#define TIMER5   0x00203000 //TIMER5�A�b�ϥΤ�U��68���A���]�wName�Ĥ@�ӡC

#define TMR0_TCTL	*((unsigned int *)(TIMER0+0x0)			//tmer control Reg.
#define TMR0_TCNT	*((unsigned int *)(TIMER0+0x4)			//tmer counter Reg.
#define TMR0_PSCL	*((unsigned int *)(TIMER0+0x8)			//prescaler devider Reg.
#define TMR0_PCNT	*((unsigned int *)(TIMER0+0xC)			//prescaler counter Reg.
#define TMR0_CCTL	*((unsigned int *)(TIMER0+0x0)			//capture control Reg.


#define	MAT0A	0x30		//match mat0a register
#define	TMSTA	0x40		//match/count flag register
#define TCTL_EN	 		0b1  << 15			//timer enable
#define	TCTL_MODE		0b00 << 2			//0b00:timer mode
#define	TCTL_START		0b1  << 0			//start
#define MAT0AIF			4

#endif
