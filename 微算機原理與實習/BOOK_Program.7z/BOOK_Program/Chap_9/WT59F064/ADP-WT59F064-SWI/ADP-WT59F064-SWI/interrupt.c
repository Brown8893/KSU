#include <nds32_intrinsic.h>

#define GPIO_ACT_PB		*((unsigned int *)0x001F6880)
#define GPIO_OEN_PB 	*((unsigned int *)0x001F6884)
#define GPIO_OMOD_PB	*((unsigned int *)0x001F6888)
#define GPIO_DAT_PB		*((unsigned int *)0x001F6890)

#define GPIO_ACT_PE		*((unsigned int *)0x001F6A00)
#define GPIO_OEN_PE 	*((unsigned int *)0x001F6A04)
#define GPIO_OMOD_PE	*((unsigned int *)0x001F6A08)
#define GPIO_DAT_PE		*((unsigned int *)0x001F6A10)

#define Digit_1	0x6000
#define Digit_2	0x4000
#define Digit_3	0x2000
#define Digit_4	0x0000
#define Digit_5	0xE000
#define Digit_6	0xC000
#define Digit_7	0xA000
#define Digit_8	0x8000

#define Number_0	0x3F3F
#define Number_1	0x0606
#define Number_2	0x5B5B
#define Number_3	0x4F4F
#define Number_4	0x6666
#define Number_5	0x6D6D
#define Number_6	0x7D7D
#define Number_7	0x2727
#define Number_8	0x7F7F
#define Number_9	0x6767
#define Number_Dot	0x8080
#define Number_A	0x0077
#define Number_B	0x7C7C
#define Number_C	0x3939
#define Number_D	0x5E5E
#define Number_E	0x7979
#define Number_F	0x7171
#define Number_N	0x5454

volatile int trigger;
volatile int g_nIntCount=0;
extern void delay1();
extern void LCMInit();
extern unsigned int LCMCheckBusyAdr();
extern void LCMCMDWR();
extern void LCMSTR();
extern void LCMSetPos();
extern unsigned int LCMDATARD();

void initIntr()
{
	/* enable SW0, HW0 and HW1 */
	//__nds32__mtsr(0x10003, NDS32_SR_INT_MASK);
	__nds32__mtsr(0x0003, NDS32_SR_INT_MASK);
	//intc_reset();


}

void clear_swi ()
{
	unsigned int int_pend;

	int_pend = __nds32__mfsr(NDS32_SR_INT_PEND);
	int_pend &= ~(0x1 << 16);
	__nds32__mtsr(int_pend, NDS32_SR_INT_PEND);
	__nds32__dsb();
}

/* User can use our handler or Default_Handler */
#if 0
void exception_handler(int exception_nr)
{
	unsigned int *led = 0x902ffffc;
	*led = exception_nr;
	//DRV_PutStr("exception handler\n");
	while(1);
}

void tlb_exception_handler(int exception_nr)
{
	unsigned int *led = 0x902ffffc;
	*led = exception_nr;
	//DRV_PutStr("tlb exception handler\n");
	while(1);
}

void error_exception_handler(int exception_nr)
{
	unsigned int *led = 0x902ffffc;
	*led = exception_nr;
	//DRV_PutStr("error exception handler\n");
	while(1);
}
#endif

void syscall_handler()
{
	static int cnt = 0;

	if (++cnt < 5)
		asm("syscall 0x5000\n\t");
		
}

void HW0_ISR()
{
	volatile unsigned int * nTIM1INTflag=(unsigned int *)0x00201C40;
//  unsigned int i;
  unsigned int * nPortEOutPutLoHi;

  if(*nTIM1INTflag==0x10)
  {

	  nPortEOutPutLoHi=(unsigned int *)0x001F6A10;
	  *nTIM1INTflag=0x10;
	  //for (i=0;i<10;i++)
	  //{
	  *nPortEOutPutLoHi|=0x08;	//0x55555555;
	  delay1(50000);
	  delay1(50000);
	  delay1(50000);
	  //*nPortEOutPutLoHi=0x0; 
	  delay1(50000);
	  delay1(50000);
	  delay1(50000);
	  delay1(50000);
	  delay1(50000);
	  delay1(50000);
	  //}
	  *nPortEOutPutLoHi^=0x08;
	  //*nTIM1INTflag=0x10;
	  //*nTIM1Start=0x8001;
  }
  //*/
	
}

void HW1_ISR()
{
	volatile unsigned int * nTIM2INTflag=(unsigned int *)0x00202040;
	volatile unsigned int * nTIM3INTflag=(unsigned int *)0x00202440;
	unsigned int nLED;
	if(*nTIM2INTflag==0x10)
	{
		*nTIM2INTflag=0x10;
		nLED=0x04;
	}
	else if(*nTIM3INTflag==0x10)
	{
		*nTIM3INTflag=0x10;
		nLED=0x20;
	}

//	unsigned int i;
  	unsigned int * nPortEOutPutLoHi;

	  nPortEOutPutLoHi=(unsigned int *)0x001F6A10;

	  *nPortEOutPutLoHi|=nLED;	//0xffffffff; 
	  delay1(50000);
	  delay1(50000);
	  delay1(50000);

	  delay1(50000);
	  delay1(50000);
	  delay1(50000);
	  delay1(50000);
	  delay1(50000);
	  delay1(50000);
	  //}
	  *nPortEOutPutLoHi^=nLED;

}

void SW0_ISR()
{

	while (LCMCheckBusyAdr() & 0x80);
	LCMSetPos(2, 1);
	while (LCMCheckBusyAdr() & 0x80);
	LCMSTR("SWI Handling");
			GPIO_DAT_PE = Number_A; //��ܼƦr
			GPIO_DAT_PB = Digit_1; //��ܲ�1���
			delay1(1000000);
			GPIO_DAT_PE = Number_B;
			GPIO_DAT_PB = Digit_2;
			delay1(1000000);
			GPIO_DAT_PE = Number_C;
			GPIO_DAT_PB = Digit_3;
			delay1(1000000);
			GPIO_DAT_PE = Number_D;
			GPIO_DAT_PB = Digit_4;

			delay1(1000000);
			delay1(1000000);
			delay1(1000000);
			delay1(1000000);
			delay1(1000000);
			GPIO_DAT_PE = 0;
			clear_swi ();

	return;
}

inline void GIE_ENABLE()
{
	__nds32__setgie_en();
	__nds32__dsb();
}

inline void GIE_DISABLE()
{
	__nds32__setgie_dis();
	__nds32__dsb();
}

 /* this function generates a s/w interrupt */
void gen_swi()
{
	unsigned int int_pend, int_mask;

	int_mask = __nds32__mfsr(NDS32_SR_INT_MASK);
	int_mask |= 1 << 16;
	__nds32__mtsr(int_mask, NDS32_SR_INT_MASK);
	int_pend = __nds32__mfsr(NDS32_SR_INT_PEND);
	int_pend |= (1 << 16);
	__nds32__mtsr(int_pend, NDS32_SR_INT_PEND);
	__nds32__dsb();
}

#if 0
void SYSirq_Disable_Interrupts_Save_Flags(unsigned int *flags)
{
	unsigned int tmp_flags;

	*flags = __nds32__mfsr(NDS32_SR_PSW) & 0x1;
	__nds32__setgie_dis();
	__nds32__dsb();
}

void SYSirq_Enable_Interrupts_Save_Flags(unsigned int *flags)
{
	unsigned int tmp_flags;

	*flags = __nds32__mfsr(NDS32_SR_PSW) & 0x1;
	__nds32__setgie_en();
	__nds32__dsb();
}
 
void SYSirq_Interrupts_Restore_Flags(unsigned int flags)
{
 	unsigned int tmp;

	tmp = __nds32__mfsr(NDS32_SR_PSW);
	tmp = __nds32__bclr(tmp, 0) | flags;
	__nds32__mtsr(tmp, NDS32_SR_PSW);
	__nds32__dsb();
}
#endif
