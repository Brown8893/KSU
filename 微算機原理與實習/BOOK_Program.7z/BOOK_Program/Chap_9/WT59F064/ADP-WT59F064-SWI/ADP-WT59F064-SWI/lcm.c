/*
#define GPIO_ACT_PD		*((unsigned int *)0x001F6980)
#define GPIO_OEN_PD 	*((unsigned int *)0x001F6984)
#define GPIO_OMOD_PD	*((unsigned int *)0x001F6988)
#define PAD_PD		 	*((unsigned int *)0x001F698C)
#define GPIO_DAT_PD		*((unsigned int *)0x001F6990)
#define GPIO_REN_PD		*((unsigned int *)0x001F6994)
#define GPIO_RS_PD		*((unsigned int *)0x001F6998)
#define GPIO_BR_PD		*((unsigned int *)0x001F699C)
#define GPIO_BS_PD		*((unsigned int *)0x001F69A0)
*/
#include "HARDWARE.h"

#define RS	0x0080
#define E	0x0040
#define RW	0x0020

void delay(unsigned int nCount)
{
	unsigned int i;
	for (i =0 ; i < nCount; i++ );
}

unsigned int LCMCheckBusyAdr()
{
	unsigned int i;
	GPIO_ACT_PD = GPIO_ACT_PD | 0xFFE0; //Initialize GPIO_D outpot
	GPIO_OEN_PD = (GPIO_OEN_PD & 0xFF1F) | 0xFF00; //PD15~8 input mode, PD7~5 output mode
	GPIO_OMOD_PD = GPIO_OMOD_PD | 0x00E0;  //PD7~5 push pull mode,

	GPIO_REN_PD = GPIO_REN_PD | 0xFF00;
	GPIO_BR_PD = E;
	GPIO_BR_PD =  RS;
	GPIO_BS_PD = RW;
	GPIO_BS_PD = E;
	delay(100);
	i = (PAD_PD & 0xff00) >> 8 ;
	GPIO_BR_PD = E;
	return i;
}


void LCMCMDWR(unsigned int cmd)
{
	GPIO_ACT_PD = GPIO_ACT_PD | 0xFFE0; //Initialize GPIO_D outpot
	GPIO_OEN_PD = GPIO_OEN_PD & 0x001F; //PD15~5 output mode
	GPIO_OMOD_PD = GPIO_OMOD_PD | 0xFFE0;  //PD15~5 push-pull mode

	GPIO_BR_PD = E;  // clear E
	GPIO_BR_PD = RS; // cmd register
	GPIO_BR_PD = RW; // write cmd

	GPIO_DAT_PD = cmd << 8; //output cmd
	delay(100);
	GPIO_BS_PD = E;		// Enable E to transfer.
	delay(100);
	GPIO_BR_PD = E;
}

void LCMDATAWR(unsigned char data)
{
	GPIO_ACT_PD = GPIO_ACT_PD | 0xFFE0; //Initialize GPIO_D outpot
	GPIO_OEN_PD = GPIO_OEN_PD & 0x001F; //PD15~5 output mode
	GPIO_OMOD_PD = GPIO_OMOD_PD | 0xFFE0;  //PD15~5 push-pull mode
	GPIO_BR_PD = E;
	GPIO_BS_PD = RS;
	GPIO_BR_PD = RW;

	GPIO_DAT_PD = (GPIO_DAT_PD & 0xff) + (data << 8);
	delay(10);
	GPIO_BS_PD = E;

	delay(100);
	GPIO_BR_PD = E;

}

unsigned int LCMDATARD()
{
	unsigned int i;
	GPIO_ACT_PD = GPIO_ACT_PD | 0xFFE0; //Initialize GPIO_D outpot
	GPIO_OEN_PD = (GPIO_OEN_PD & 0xFF1F) | 0xFF00; //PD15~8 input mode, PD7~5 output mode
	GPIO_OMOD_PD = GPIO_OMOD_PD | 0x00E0;  //PD7~5 push pull mode,
	GPIO_RS_PD = GPIO_RS_PD | 0xFF00;
	GPIO_REN_PD = GPIO_REN_PD | 0xFF00;
	GPIO_BR_PD = E;
	GPIO_BS_PD = RS;
	GPIO_BS_PD = RW;
	GPIO_BS_PD = E;
	//PAD_PD = PAD_PD + RS + RW + E;
	delay(100);
	i = (PAD_PD & 0xff00) >> 8;
	GPIO_BR_PD = E;
	return i;
}

void LCMInit(void)
{
    LCMCMDWR(0x38);

    LCMCMDWR(0x38);

	LCMCMDWR(0x38);
    while (LCMCheckBusyAdr() & 0x80)		;
	LCMCMDWR(0x38); //8 bits interface,  2 line display , 5*8 font
    while (LCMCheckBusyAdr() & 0x80) 		;
	LCMCMDWR(0x09); //display off, cursor off, blinking
    while (LCMCheckBusyAdr() & 0x80)   		;
	LCMCMDWR(0x01); // clear display
    while (LCMCheckBusyAdr() & 0x80)    		;
	LCMCMDWR(0x0C); //display on, cursor off ,
    while (LCMCheckBusyAdr() & 0x80)
    		;
    LCMCMDWR(0x06); // acc increment, no shift
}

void LCMClrDisplay()
{
	while (LCMCheckBusyAdr() & 0x80) ;
	LCMCMDWR(0x01); //Clear All DDRam contents and set ACC to 0
}

void LCMCurHome()
{
	while (LCMCheckBusyAdr() & 0x80) ;
	LCMCMDWR(0x02); //Sets DDRAM address 0 ACC
}

void LCMSetPos(unsigned i, unsigned j)
{
	while (LCMCheckBusyAdr() & 0x80)
		;
	LCMCMDWR((i-1)*0x40+j-1+0x80);
}

void LCMSTR(unsigned char *pSTR)
{
	while (*pSTR != '\0')
	{
		while (LCMCheckBusyAdr() & 0x80)
				;
		LCMDATAWR(*pSTR);
		pSTR++;
	}
}

