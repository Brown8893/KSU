#include "nds32_intrinsic.h"

#define GPIO_ACT_PB		*((unsigned int *)0x001F6880)
#define GPIO_OEN_PB 	*((unsigned int *)0x001F6884)
#define GPIO_OMOD_PB	*((unsigned int *)0x001F6888)
#define GPIO_DAT_PB		*((unsigned int *)0x001F6890)

#define GPIO_ACT_PD		*((unsigned int *)0x001F6980)
#define GPIO_OEN_PD 	*((unsigned int *)0x001F6984)
#define GPIO_OMOD_PD	*((unsigned int *)0x001F6988)
#define PAD_PD		 	*((unsigned int *)0x001F698C)
#define GPIO_DAT_PD		*((unsigned int *)0x001F6990)
#define GPIO_REN_PD		*((unsigned int *)0x001F6994)
#define GPIO_RS_PD		*((unsigned int *)0x001F6998)

#define GPIO_ACT_PE		*((unsigned int *)0x001F6A00)
#define GPIO_OEN_PE 	*((unsigned int *)0x001F6A04)
#define GPIO_OMOD_PE	*((unsigned int *)0x001F6A08)
#define GPIO_DAT_PE		*((unsigned int *)0x001F6A10)

#define RS	0x0080
#define E	0x0040
#define RW	0x0020
#define CleanSet 0x0000

#define Digit_1	0x6000
#define Digit_2	0x4000
#define Digit_3	0x2000
#define Digit_4	0x0000
#define Digit_5	0xE000
#define Digit_6	0xC000
#define Digit_7	0xA000
#define Digit_8	0x8000

#define Number_0	0x3F3F
#define Number_1	0x0606
#define Number_2	0x5B5B
#define Number_3	0x4F4F
#define Number_4	0x6666
#define Number_5	0x6D6D
#define Number_6	0x7D7D
#define Number_7	0x2727
#define Number_8	0x7F7F
#define Number_9	0x6767
#define Number_Dot	0x8080

#define Interrupt_0	*((unsigned int *)0x00200D00) //MCU Interrupt 0
#define Interrupt_1	*((unsigned int *)0x00200D08) //MCU Interrupt 1

#define GPIO_ACT_PA	*((unsigned int *)0x001F6800) //GPIO port A
#define GPIO_ACT_PD	*((unsigned int *)0x001F6980) //GPIO port D

#define UART0_Countrol_Reg_1	*((unsigned int *)0x00203400) //UART0
#define UART0_Countrol_Reg_2	*((unsigned int *)0x00203404) //UART0
#define UART0_TransmitData_Reg	*((unsigned int *)0x0020340C) //UART0
#define UART0_BaudRate_Reg		*((unsigned int *)0x00203414) //UART0

#define UART3_Countrol_Reg_1	*((unsigned int *)0x00204000) //UART3
#define UART3_Countrol_Reg_2	*((unsigned int *)0x00204004) //UART3
#define UART3_TransmitData_Reg	*((unsigned int *)0x0020340C) //UART3
#define UART3_BaudRate_Reg		*((unsigned int *)0x00204014) //UART3

#define FALSE 0
#define TRUE  1
#define UART_TXD_BUFFER_SIZE	24
#define _EOS_	'\0' //End of string

typedef unsigned short U16;
typedef unsigned char U8;
typedef volatile struct
{
	unsigned char fTxComplete:1;
	unsigned char fOverRun:1;

	unsigned char Resver:6;
} sUartFlag;

sUartFlag gsUart0Flag;
sUartFlag gsUart3Flag;

extern void initIntr();
extern void GIE_ENABLE();
extern void gen_swi();

extern void LCMInit();
extern unsigned int LCMCheckBusyAdr();
extern void LCMCMDWR();
extern void LCMSTR();
extern void LCMSetPos();
extern unsigned int LCMDATARD();
char u8TxdBuf[UART_TXD_BUFFER_SIZE];

void delay1(unsigned int nCount)
{
   unsigned int i;
   for(i=0;i<nCount;i++);
}

void CheckBusy(void) //BF ,CHACK BUSY FLAG
{
	unsigned short int i=0x8000;
	while(i&0x8000)
	{
		GPIO_ACT_PD = 0xFFFF; //Initialize GPIO_D outpot
		GPIO_OMOD_PD = 0x0;
		GPIO_OEN_PD = 0x0;

		GPIO_DAT_PD = (RW + E);

		GPIO_ACT_PD = 0xFF00; //Initialize GPIO_D input
		GPIO_RS_PD = 0xFF00;
		GPIO_REN_PD = 0xFF00;

		i = PAD_PD;

		GPIO_DAT_PD = CleanSet;
		delay1(100000);
	}
}

void WriteData(unsigned short int i)
{
	GPIO_ACT_PD = 0xFFFF; //Initialize GPIO_D outpot
	GPIO_OMOD_PD = 0x0;
	GPIO_OEN_PD = 0x0;

	GPIO_DAT_PD = ((i << 8) + RS + E);
	GPIO_DAT_PD = CleanSet;
	CheckBusy();
}

void WriteIns(unsigned short int instruction)
{
	GPIO_ACT_PD = 0xFFFF; //Initialize GPIO_D outpot
	GPIO_OMOD_PD = 0x0;
	GPIO_OEN_PD = 0x0;

	GPIO_DAT_PD = (instruction + E );
	GPIO_DAT_PD = CleanSet;

	CheckBusy();
}

void InitialLCD(void)
{
	WriteIns(0x3800);  //FUNCTION SET
	WriteIns(0x3800);
	WriteIns(0x3800);
	WriteIns(0x3800);
	WriteIns(0x0800);  // off display
	WriteIns(0x0100);  // clear buffer
	WriteIns(0x0e00);  // on display
	WriteIns(0x0600);  // set input mode
}


void DRV_PutChar(char u8Char)
{
	U16 u16Count;

	UART0_TransmitData_Reg = u8Char;
	gsUart0Flag.fTxComplete = FALSE;

	u16Count = 0;
	while(FALSE == gsUart0Flag.fTxComplete) //Flag clear using interrupt function.
	{
		//Don't delete.
		//-----Time out
		u16Count++;
		if(u16Count >= 1000) //BaudRate=38400
		//if(u16Count >= 100) //BaudRate=115200
		{
			break;
		}
	}
}

void DRV_PutStr(const char *pFmt)
{
	U8 u8Buffer;	//Character buffer

	while (1)
	{
		u8Buffer = *pFmt; //Get a character
		if(u8Buffer == _EOS_) //Check end of string
			break;

		DRV_PutChar(u8Buffer); //Put a character
		pFmt++;
	}
}

void DRV_IntToStr(U16 u16Val, U8 u8Base, char *pBuf, U8 u8Length)
{
	U8 bShowZero = FALSE;
	U16 u16Divider;
	U8 u8Disp;
	U16 u16Temp;

	u8Length -= 1;
	if(u8Base == 16) //Hex
	{
		u16Temp = 0x01 << u8Length;
	}
	else //Dec
	{
		u16Temp = 1;
		while(u8Length--)
		{
			u16Temp *= 10;
		}
	}

	if( 0 == u16Val )
	{
		if( 16 == u8Base )
		{
			pBuf[0] = '0';
			pBuf[1] = '0';
			pBuf[2] = '0';
			pBuf[3] = '0';
			pBuf[4] = '\0';
		}
		else
		{
			pBuf[0] = '0';
			pBuf[1] = '0';
			pBuf[2] = '0';
			pBuf[3] = '0';
			pBuf[4] = '0';
			pBuf[5] = '\0';
		}
		return;
	}

	if( 16 == u8Base )
	{
		u16Divider = 0x1000;
	}
	else
	{
		u16Divider = 10000;
	}

	while( u16Divider )
	{
		u8Disp = u16Val / u16Divider;
		u16Val = u16Val % u16Divider;

		if(u16Temp == u16Divider)
		{
			bShowZero = TRUE;
		}
		if( u8Disp || bShowZero || (u16Divider>0))
		{
			if( u8Disp < 10 )
				*pBuf = '0' + u8Disp;
			else
				*pBuf = 'A' + u8Disp - 10;
			pBuf ++;
		}

		if( 16 == u8Base )
		{
			u16Divider /= 0x10;
			if(bShowZero)
				u16Temp /= 0x10;
		}
		else
		{
			u16Divider /= 10;
			if(bShowZero)
				u16Temp /= 10;
		}
	}
	*pBuf = '\0';
}

int main()
{

	LCMInit();
	while (LCMCheckBusyAdr() & 0x80);
	LCMSetPos(1, 1);

	while (LCMCheckBusyAdr() & 0x80);
	LCMSTR("SWI TEST");
	initIntr();
	GIE_ENABLE();


	GPIO_ACT_PB = 0xFFFF; //Initialize GPIO_B
	GPIO_OMOD_PB = 0x0;
	GPIO_OEN_PB = 0x0;

	GPIO_ACT_PE = 0xFFFF; //Initialize GPIO_E
	GPIO_OMOD_PE = 0x0;
	GPIO_OEN_PE = 0x0;
	while(1)
	{
		gen_swi();
		LCMSetPos(2, 1);
		while (LCMCheckBusyAdr() & 0x80);
		LCMSTR("SWI Ends     ");
		delay1(1000000);
		delay1(1000000);
	}

	return 0;
}
