#ifndef HARDWARE_H_
#define HARDWARE_H_


#define	inw(reg)		(*((volatile unsigned int *) (reg)))
#define	outw(reg, data) ((*((volatile unsigned int *)(reg)))=(unsigned int)(data))


/************************************
 *  TARGET INTERRUPT CONSTANTS      *
 ************************************/
/* intc */
#define INTC_BASE              0x98800000  /* Interrupt Controller base address */
#define IRQSRCR_OFFSET         0x00        /* IRQ(HW1) Source Register offset */
#define IRQER_OFFSET           0x04        /* IRQ(HW1) Enable Register offset */
#define IRQICR_OFFSET          0x08        /* IRQ(HW1) Interrupt Clear Register offset */
#define IRQTMR_OFFSET          0x0C        /* IRQ(HW1) Trigger Mode Register offset */
#define IRQTLR_OFFSET          0x10        /* IRQ(HW1) Trigger Level Register offset */
#define IRQSR_OFFSET           0x14        /* IRQ(HW1) Status Register offset */
#define FIQSRCR_OFFSET         0x20        /* FIQ(HW0) Source Register offset */
#define FIQER_OFFSET           0x24        /* FIQ(HW0) Enable Register offset */
#define FIQICR_OFFSET          0x28        /* FIQ(HW0) Interrupt Clear Register offset */
#define FIQTMR_OFFSET          0x2C        /* FIQ(HW0) Trigger Mode Register offset */
#define FIQTLR_OFFSET          0x30        /* FIQ(HW0) Trigger Level Register offset */
#define FIQSR_OFFSET           0x34        /* FIQ(HW0) Status Register offset */
#define INT_IRQER_INIT         0x00000000  /* values used to disable all interrupts */
#define INT_CLEAR_VALUE        0xFFFFFFFF  /* values used to clear all pending interrupts */

/* timer */
#define TIMER_BASE             0x98400000  /* Define base for all timer registers */
#define TIMER1_CNT_OFFSET      0x00        /* Offset for timer1 counter register */
#define TIMER1_LOAD_OFFSET     0x04        /* Offset for timer1 load register */
#define TIMER1_MATCH1_OFFSET   0x08        /* Offset for timer1 counter */
#define TIMER1_MATCH2_OFFSET   0x0c        /* Offset for timer1 counter */
#define TIMER2_CNT_OFFSET      0x10        /* Offset for timer2 counter register */
#define TIMER2_LOAD_OFFSET     0x14        /* Offset for timer2 load register */
#define TIMER2_MATCH1_OFFSET   0x18        /* Offset for timer2 counter */
#define TIMER2_MATCH2_OFFSET   0x1c        /* Offset for timer2 counter */
#define TIMER3_CNT_OFFSET      0x20        /* Offset for timer3 counter register */
#define TIMER3_LOAD_OFFSET     0x24        /* Offset for timer3 load register */
#define TIMER3_MATCH1_OFFSET   0x28        /* Offset for timer3 counter */
#define TIMER3_MATCH2_OFFSET   0x2c        /* Offset for timer3 counter */
#define TIMER_CNTRL_OFFSET     0x30        /* Offset for timer control register */
#define TIMER_INTS_OFFSET      0x34        /* Offset for timer interrupt status register */
#define TIMER_INTM_OFFSET      0x38        /* Offset for timer interrupt mask register */

#define INTC_TIMER1_MASK        0x00080000  /* Mask to enable timer interrupt */
#define INTC_TIMER1_CLEAR_VALUE 0x00080000  /* Value to clear pending timer1 interrupt */
#define INTC_TIMER_CLEAR_VALUE  0x0008c000  /* Value to clear all pending timer interrupt */
#define INTC_TIMER1_TRIGGER     0x00080000  /* bit 19  = 1: Edge trigger */
#define INTC_TIMER1_LEVEL       0x00000000  /* bit 19  = 0: Falling edge Trigger */

#define TIMER1_INTM_INIT        0x00000003  /* Mask out timer1 match interrupts */
#define TIMER_CNTRL_DISABLE     0x00000000  /* Value to disable timer */
#define TIMER1_CTRL_INIT        0x00000005  /* Bit 2   = 1, enalbe timer1 interrupt */
                                            /* Bit 1   = 1, clock source, PCLK */
					    /* Bit 0   = 1, enable timer1 */
#define TIMER1_INTS_CLEAR_MASK  0xfffffff8  /* Clear mask of timer status register */

/* GPIO controller */

#define GPIO_BASE				0xF07000  /* GPIO base address */
#define	GPIO_DOUT_OFFSET	   	0x0
#define	GPIO_DIN_OFFSET			0x4
#define	GPIO_DIR_OFFSET			0x8
#define	GPIO_DSET_OFFSET		0x10
#define	GPIO_DCLEAR_OFFSET		0x14
#define	GPIO_PE_OFFSET			0x18
#define	GPIO_PT_OFFSET			0x1C
#define	GPIO_IE_OFFSET			0x20
#define	GPIO_IS_OFFSET			0x24
#define	GPIO_IMS_OFFSET			0x28
#define	GPIO_IM_OFFSET			0x2C

#define	GPIO_IT_OFFSET			0x34
#define	GPIO_IC_OFFSET			0x30
#define	GPIO_IB_OFFSET			0x38
#define	GPIO_IR_OFFSET			0x3c
#define GPIO_BE_OFFSET			0x40
#define GPIO_BP_OFFSET			0x44


#endif /*HARDWARE_H_*/
