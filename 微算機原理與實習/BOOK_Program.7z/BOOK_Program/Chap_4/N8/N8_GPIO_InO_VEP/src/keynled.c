//ROW 1 & 3 are used as keys, ROW 2 & 4 are used as leds in order display the key pressed
//ROW 1 is set in rising edge, ROW 3 is set in falling edge, so after releasing the keys in row3
// the corresponding led lights.
#include "hardware.h"
extern void gpio_init();
void delay(int time);

int main (int argc, char *argv[])
{
	int key_status=0, led_status;
	gpio_init ();
	outw (GPIO_BASE + GPIO_DOUT_OFFSET, 0x0);

	while (1)
	{
		key_status = inw(GPIO_BASE + GPIO_IS_OFFSET);
		led_status = (key_status & 0xff00ff);
		if( led_status != 0)
		{
			//outw (GPIO_BASE + GPIO_DOUT_OFFSET, 0x0);

			outw (GPIO_BASE + GPIO_DOUT_OFFSET, led_status  << 8);

			//int_status = inw(GPIO_BASE + GPIO_DIN_OFFSET);

			//int_status=((!inw(GPIO_BASE + GPIO_DIN_OFFSET) << 8) & 0xff000000) | inw(GPIO_DOUT_OFFSET));

			//outw (GPIO_BASE + GPIO_DOUT_OFFSET,((inw(GPIO_BASE + GPIO_DIN_OFFSET)<<8)&0xff000000^0xff000000)| inw(GPIO_BASE + GPIO_DOUT_OFFSET));
			delay(100);
			outw (GPIO_BASE + GPIO_IC_OFFSET, 0xff00ff);
		}
	}
}

void delay(int time)
{
	while(time>0)
	time--;
}
