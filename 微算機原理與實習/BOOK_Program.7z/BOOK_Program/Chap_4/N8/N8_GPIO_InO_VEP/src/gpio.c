
#include "hardware.h"

void gpio_init ()
{

	outw (GPIO_BASE + GPIO_DIR_OFFSET, 0xff00ff00);//gpio0~7 , gpio16~23 interrupt pin
												   // gpio8~15, gpio24~31 output pin
	outw (GPIO_BASE + GPIO_PE_OFFSET, 0x0);		/* pull disable */
	outw (GPIO_BASE + GPIO_IT_OFFSET, 0x00000000);	// edge trigger mode
	outw (GPIO_BASE + GPIO_IR_OFFSET, 0xFF0000);		//0:rising triggl, 1:falling edge
	outw (GPIO_BASE + GPIO_IB_OFFSET, 0x0);			//single edge triggle
	outw (GPIO_BASE + GPIO_IC_OFFSET, 0xffffffff);  //clear the status reg.
	outw (GPIO_BASE + GPIO_IM_OFFSET, 0x0);  //disable mask.
	outw (GPIO_BASE + GPIO_BP_OFFSET, 0x7D0 );  //bounce prescale
	outw (GPIO_BASE + GPIO_BE_OFFSET, 0xffffffff);			//bounce enable
	outw (GPIO_BASE + GPIO_IE_OFFSET, 0xff00ff);		//enable interrupt
}
