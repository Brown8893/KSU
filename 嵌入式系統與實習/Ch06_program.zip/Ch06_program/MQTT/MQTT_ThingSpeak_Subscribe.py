#http://rocksaying.tw/archives/2016/MQTT-3-Python-clients.html
# coding: utf-8
###   Start of user configuration   ###   

#  ThingSpeak Channel Settings

# The ThingSpeak Channel ID
# Replace this with your Channel ID
channelID = "xxxxxx"

# The Read API Key for the channel
# Replace this with your Read API key
apiKey = "D5XXXXXXXXXXXZE"
api_key_read = "xxxxxxxxxxxxxxxx"
mqtt_server ="mqtt.thingspeak.com"

import sys, os, time, signal, Adafruit_DHT
import importlib,sys 
import paho.mqtt.client as mqtt

importlib.reload(sys)
sensor = Adafruit_DHT.DHT22
pin = 24 #GPIO24

client = None
mqtt_looping = False

inTopic = "channels/"+channelID+"/subscribe/fields/+/"+api_key_read

def on_connect(mq, userdata, rc, _):
    # subscribe when connected.
    mq.subscribe(inTopic)

def on_message(mq, userdata, msg):
    print ("topic: %s" % msg.topic)
    print ("payload: %s" % msg.payload)
    print ("qos: %d" % msg.qos)

def mqtt_client_thread():
    global client, mqtt_looping
    client_id = "" # If broker asks client ID.
    client = mqtt.Client(client_id=client_id)

    # If broker asks user/password.
    user = "jXXXXXXXXX"
	#Replace mqttpassword with your password.
    mqttpassword = "6**************L"
    client.username_pw_set(user, mqttpassword)

    client.on_connect = on_connect
    client.on_message = on_message

    try:
        client.connect(mqtt_server,1883)
    except:
        print ("MQTT Broker is not online. Connect later.")

    mqtt_looping = True
    print ("Looping...")

    #mqtt_loop.loop_forever()
    cnt = 0
    while mqtt_looping:
        client.loop()

        cnt += 1
        if cnt > 20:
            try:
                client.reconnect() # to avoid 'Broken pipe' error.
            except:
                time.sleep(1)
            cnt = 0

    print ("quit mqtt thread")
    client.disconnect()

def stop_all(*args):
    global mqtt_looping
    mqtt_looping = False

if __name__ == '__main__':
    signal.signal(signal.SIGTERM, stop_all)
    signal.signal(signal.SIGQUIT, stop_all)
    signal.signal(signal.SIGINT,  stop_all)  # Ctrl-C

    mqtt_client_thread()

    print ("exit program")
    sys.exit(0)		
