#Update a ThingSpeak Channel using MQTT on a Raspberry Pi
#https://community.thingspeak.com/tutorials/update-a-thingspeak-channel-using-mqtt-on-a-raspberry-pi/
#
# ThingSpeak Update Using MQTT
# Copyright 2016, MathWorks, Inc

# This is an example of publishing to multiple fields simultaneously.
# Connections over standard TCP, websocket or SSL are possible by setting
# the parameters below.
#
# Temperature and Humidity  are collected every 15 seconds and published to a
# ThingSpeak channel using an MQTT Publish
#
# This example requires the Paho MQTT client package which
# is available at: http://eclipse.org/paho/clients/python

from __future__ import print_function
import paho.mqtt.publish as publish
import Adafruit_DHT
import sys
import time

sensor = Adafruit_DHT.DHT22
pin = 24 #GPIO24

###   Start of user configuration   ###   

#  ThingSpeak Channel Settings

# The ThingSpeak Channel ID
# Replace this with your Channel ID
channelID = "xxxxxx"

# The Write API Key for this channel
# Replace this with your Write API key
apiKey = "xxxxxxxxxxxxxxxx"

#  MQTT Connection Methods

# Set useUnsecuredTCP to True to use the default MQTT port of 1883
# This type of unsecured MQTT connection uses the least amount of system resources.
useUnsecuredTCP = False

# Set useUnsecuredWebSockets to True to use MQTT over an unsecured websocket on port 80.
# Try this if port 1883 is blocked on your network.
useUnsecuredWebsockets = True

# Set useSSLWebsockets to True to use MQTT over a secure websocket on port 443.
# This type of connection will use slightly more system resources, but the connection
# will be secured by SSL.
useSSLWebsockets = False

###   End of user configuration   ###

# The Hostname of the ThinSpeak MQTT service
mqttHost = "mqtt.thingspeak.com"

# Set up the connection parameters based on the connection type
if useUnsecuredTCP:
    tTransport = "tcp"
    tPort = 1883
    tTLS = None

if useUnsecuredWebsockets:
    tTransport = "websockets"
    tPort = 80
    tTLS = None

if useSSLWebsockets:
    import ssl
    tTransport = "websockets"
    tTLS = {'ca_certs':"/etc/ssl/certs/ca-certificates.crt",'tls_version':ssl.PROTOCOL_TLSv1}
    tPort = 443
        
# Create the topic string
topic = "channels/" + channelID + "/publish/" + apiKey

# Run a loop which calculates the system performance every
#   20 seconds and published that to a ThingSpeak channel
#   using MQTT.
while(True):
    # get the DHT sensor data
    [humidity, temperature] = Adafruit_DHT.read_retry(sensor, pin)
    if (humidity is not None) and (temperature is not None):
        #print('Temperature={0:0.1f}°C Humidity={1:0.1f}%'.format(temperature, humidity))
        print("temperature = %.02f°C humidity =%.02f%%"%(temperature, humidity))
    else:
        print('Failed to get reading. Try again!')
        sys.exit(1)
		
    # build the payload string
    tPayload = "field1=" + str(temperature) + "&field2=" + str(humidity)

    # attempt to publish this data to the topic 
    try:
        publish.single(topic, payload=tPayload, hostname=mqttHost, port=tPort, tls=tTLS, transport=tTransport)
        print("Publish Temperature & Humidity")
        time.sleep(15)

    except (KeyboardInterrupt):
        break

    except:
        print ("There was an error while publishing the data.")
