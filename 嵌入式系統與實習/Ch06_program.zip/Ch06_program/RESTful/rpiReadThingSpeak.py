#**************************************************** 
# Import Package                                                                           
#**************************************************** 
import Adafruit_DHT
import sys  
import time  
import http.client
from urllib  import parse, request
import json
#sys.path.append('/home/pi/rpi/code/Package')  

#**************************************************** 
# Set Pin No, ThingSpeak Key                                                                          
#**************************************************** 

sensor = Adafruit_DHT.DHT22
pin =  24 #GPIO24

#Replace it with your Read API Key
#Read API Key
thingSpeakApiKey = "JDSYBXIQL3KONQ0S"
#Replace your ThingSpeak channel ID
CHANNEL_ID = "649057"

#**************************************************** 
# Set ThingSpeak Connection                                                   
#**************************************************** 
def getdata():
    req = request.Request("https://api.thingspeak.com/channels/%s/feeds/last.json?api_key=%s" \
                           % (CHANNEL_ID,thingSpeakApiKey))

    conn = request.urlopen(req)
    response = conn.read()
    print("HTTP Request method=%s" %(req.get_method()))
    print ("Response from %s" % (conn.geturl()))
    print ("http status code=%s" % (conn.getcode()))
    print ("Response=%s" % (conn.info()))    
    print("Response from Webserver: ", response)
    data=json.loads(response.decode('utf-8'))
    print (data['field1'],data['created_at'])
    conn.close()

def getdata_post():
    """
    req = request.Request("https://api.thingspeak.com/channels/%s/feeds/last.json?api_key=%s" \
                           % (CHANNEL_ID,thingSpeakApiKey))
    """
    data = {"results": "1"}
    params = parse.urlencode(data).encode('utf8')
    
    req = request.Request("http://api.thingspeak.com/channels/271790/fields/1.json?api_key=KJQHZUDFEBTS4DL0", params)
    conn = request.urlopen(req)
    response = conn.read()
    print("HTTP method=%s" %(req.get_method()))
    #print ("Response from %s" % (conn.geturl()))
    print ("http status code=%s" % (conn.getcode()))
    print ("Response=%s" % (conn.info()))
    print("response: ", response)
    data=json.loads(response.decode('utf-8'))
    print(data)
    print (data['field1'],data['created_at'])
    conn.close()
	
def post_to_thingspeak(payload):  
    headers = {"Content-type": "application/x-www-form-urlencoded","Accept": "text/plain"}
    not_connected = 1
    while (not_connected):
        try:
            conn = http.client.HTTPConnection("api.thingspeak.com:80")
            conn.connect()
            not_connected = 0
        except (httplib.HTTPException, socket.error) as ex:
            print("Error: %s" % ex)
            time.sleep(10)  # sleep 10 seconds

    conn.request("POST", "https://api.thingspeak.com/channels/271790/fields/1.json HTTP/1.1 ", payload, headers)
    response = conn.getresponse()
    print( response.status, response.reason, payload, time.strftime("%c"))
    data = response.read().decode('utf-8')
    json_obj=json.loads(data)
    field1name=json_obj["channel"]["field1"]
    print (field1name,"=",json_obj["feeds"][0]["field1"])
    conn.close()
	
def get_to_thingspeak(payload):  
    headers = {"Content-type": "application/x-www-form-urlencoded","Accept": "text/plain"}
    not_connected = 1
    while (not_connected):
        try:
            conn = http.client.HTTPConnection("api.thingspeak.com:80")
            conn.connect()
            not_connected = 0
        except (httplib.HTTPException, socket.error) as ex:
            print("Error: %s" % ex)
            time.sleep(10)  # sleep 10 seconds

    conn.request("GET", "/channels/271790/fields/1.json", payload, headers)
    response = conn.getresponse()
    print( response.status, response.reason, payload, time.strftime("%c"))
    data = response.read().decode('utf-8')
    print(data)
    json_obj=json.loads(data)
    field1name=json_obj["channel"]["field1"]
    print (field1name,"=",json_obj["feeds"][0]["field1"])
    #entry= json_obj["feeds"]
    #print(entry[0]["field1"])
    conn.close()		

#**************************************************** 
# Post ThingSpeak                                                  
#**************************************************** 
while True:  
    #[humidity, temp] = Adafruit_DHT.read_retry(sensor, pin)  
    #print("temp = %.02f*C humidity =%.02f%%"%(temp, humidity))
    getdata()
    time.sleep(5)
    getdata_post()
    time.sleep(5)	
    params = parse.urlencode({'results': '1', 'key': thingSpeakApiKey})
    print(params.encode())
    #post_to_thingspeak(params)
    #get_to_thingspeak(params)
    #time.sleep(5)
