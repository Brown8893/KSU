import cv2
import numpy as np
from matplotlib import pyplot as plt
from PIL import Image
from pylab import *

img = cv2.imread('../data/lena.jpg', 0)
ret, th1 = cv2.threshold(img, 127, 255, cv2.THRESH_BINARY)
pil_im = Image.open('../data/lena.jpg')

titles = [ 'BINARY']
images = [pil_im,th1]

for i in range(2):
    plt.subplot(2, 3, i+1), plt.imshow(images[i], 'gray')
    axis('off')
    
plt.show()