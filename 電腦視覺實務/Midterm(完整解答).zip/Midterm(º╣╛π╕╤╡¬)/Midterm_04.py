# -*-coding:utf-8-*-
import cv2
from PIL import Image
from numpy import *
from pylab import *
from PCV.tools import imtools
import matplotlib.pyplot as plt
im = Image.open('../data/color.jpg')
# 圖片的寬度和高度
img_size = im.size
print("圖片寬度和高度分別是{}".format(img_size))
'''
裁剪：傳入一個元組作為參數
元組裏的元素分別是：（距離圖片左邊界距離x， 距離圖片上邊界距離y，距離圖片左邊界距離+裁剪框寬度x+w，距離圖片上邊界距離+裁剪框高度y+h）
'''
# 截取圖片中一塊寬和高都是250的
x = 0
y = 0
w = 200
h = 394
region = im.crop((x, y, x+w, y+h))
region.save("./crop_test1.jpeg")

# 截取圖片中一塊寬是250和高都是300的
x = 200
y = 0
w = 200
h = 394
region = im.crop((x, y, x+w, y+h))
region.save("./crop_test2.jpeg")
# 截取圖片中一塊寬是250和高都是300的
x = 400
y = 0
w = 200
h = 394
region = im.crop((x, y, x+w, y+h))
region.save("./crop_test3.jpeg")
# 截取圖片中一塊寬是250和高都是300的
x = 600
y = 0
w = 200
h = 394
region = im.crop((x, y, x+w, y+h))
region.save("./crop_test4.jpeg")
img = Image.open("./crop_test1.jpeg")
img1= Image.open("./crop_test2.jpeg")
img2= Image.open("./crop_test3.jpeg")
img3= Image.open("./crop_test4.jpeg")
im = array(Image.open('./crop_test1.jpeg').convert('L'))
im1 = array(Image.open('./crop_test2.jpeg').convert('L'))
im2 = array(Image.open('./crop_test3.jpeg').convert('L'))
im3 = array(Image.open('./crop_test4.jpeg').convert('L'))
figure()
subplot(241)
axis('off')
imshow(img)
subplot(242)
axis('off')
imshow(img1)
subplot(243)
axis('off')
imshow(img2)
subplot(244)
axis('off')
imshow(img3)
subplot(245)
axis('off')
#hist(im.flatten(), 128, cumulative=True, normed=True)
hist(im.flatten(), 64)
subplot(246)
axis('off')
#hist(im.flatten(), 128, cumulative=True, normed=True)
hist(im1.flatten(), 128)
subplot(247)
axis('off')
#hist(im.flatten(), 128, cumulative=True, normed=True)
hist(im2.flatten(), 128)
subplot(248)
axis('off')
#hist(im.flatten(), 128, cumulative=True, normed=True)
hist(im3.flatten(), 128)

