from PIL import Image
from pylab import *
from scipy.ndimage import filters
import cv2

img = Image.open("../data/fig1a.jpg")#子圖檔案名
icon = Image.open("../data/fig1b.jpg")#子圖檔案名

icon = icon.resize((600, 300))
imshow(icon)

# 獲取圖片的寬高
img_w, img_h = img.size #獲取被放圖片的大小（母圖）
icon_w,icon_h=icon.size #獲取小圖的大小（子圖）
factor = 6
size_w = int(img_w / factor)
size_h = int(img_h / factor)
icon_w, icon_h = icon.size
#防止子圖尺寸大於母圖

if icon_w > size_w:
    icon_w = size_w
if icon_h > size_h:
    icon_h = size_h
# # 重新設置子圖的尺寸
# icon = icon.resize((icon_w, icon_h), Image.ANTIALIAS)
w = int((img_w - icon_w) / 5)
h = int((img_h - icon_h) / 5)
# 粘貼圖片
img.paste(icon, (250, 600), mask=None)
axis('off')
# 保存圖片
imshow(img)
img.save("../data/AAA.jpg")#合成後的圖片路徑以及檔案名
