from PIL import Image
from pylab import *
from scipy.ndimage import filters
import cv2
 
img = cv2.imread("../data/fig1b.jpg")
print(img.shape)
cropped = img[150:220, 220:350]  # 裁剪坐标为[y0:y1, x0:x1]
cv2.imwrite("../data/fig1c.jpg", cropped)
imshow(cropped)
axis('off')