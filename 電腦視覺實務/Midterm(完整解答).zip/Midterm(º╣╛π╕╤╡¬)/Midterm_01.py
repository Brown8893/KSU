# -*- coding: utf-8 -*-
from PIL import Image
from pylab import *


x = [100, 400, 100, 400]    #x座標的點
y = [200, 500, 200, 500]    #y座標的點

#axis('off')

#原圖
pil_im = Image.open('../data/cat.jpg')
subplot(121)
axis('on')
imshow(pil_im)

#旋轉後的圖
pil_im = Image.open('../data/cat.jpg')
pil_im = pil_im.rotate(45)
subplot(122)
axis('on')
imshow(pil_im)

show()