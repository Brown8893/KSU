<!DOCTYPE html>
<html>
<body>

	<?php
		$x = 1;
		
		while($x <= 5) {
			echo "The number is: $x <br>";
			$x++;
		}
	?>
</body>
</html>