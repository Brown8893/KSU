<?php
 $db_host = "localhost";
 $db_name = "ksu_database";
 $db_table = "ksu_cstd_table";
 $db_user = "root";
 $db_password = "";
 
 // 連結檢測
 $conn = mysqli_connect($db_host, $db_user, $db_password);
 if(empty($conn)){
	print  mysqli_error ($conn);
    die ("無法對資料庫連線！" );
	exit;
 }  
 if(!mysqli_select_db( $conn, $db_name)){
	die("資料庫不存在!");
	exit;
 }  

 //自型設定  
 mysqli_set_charset($conn,'utf8');
      
 echo "ksu_std_table  學生於各系人數顯示如下:". "<br/><br/>"; 
 $result = mysqli_query($conn,
                        "SELECT COUNT(DISTINCT (ksu_std_department))
						 FROM ksu_std_table
						 GROUP BY ksu_std_department");
 $row_num = 0;

 //使用 mysqli_fetch_array() 取回資料庫資料
 while($row = mysqli_fetch_array($result))
 {  
	$row_num = $row_num + 1;
 }
 echo "共" . $row_num . "個不同的系"."<br/><br/>";

?> 
<form enctype="multipart/form-data"  method="post" action="ksu_select61.html">
<input type="submit" name="sub" value="返回"/>
</form>