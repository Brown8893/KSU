<!DOCTYPE html>
<html>
<body>

	<?php
		$colors = array("red", "green", "blue", "yellow");
		
		foreach ($colors as $value) {
			echo "$value <br>";
		}
	?>
</body>
</html>