<!DOCTYPE html>
<html>
<body>

	<?php
		$x = "Kun-Shan University!";
		$y = "IE";
		
		echo $x;
		echo "<br>";
		echo $y;
	?>
</body>
</html>