<!DOCTYPE html>
<html>
<body>

	<?php
		$age = array("Peter"=>"35", "Ben"=>"37", "William"=>"55",);
		
		foreach ($age as $x => $val) {
			echo "$x = $val <br>";
		}
	?>
</body>
</html>