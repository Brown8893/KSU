<?php
      echo "搭配loop 與 變數 \$i <br>";
 	  echo "變數\$i的起始值為8, 終止值為3 <br>";
	  echo "每次減1,呈現如下<br><br>"; 
	  
      for ($i = 8 ; $i >= 3; $i--){
          echo " \$i = " .$i. "<br>"; 
      }      
?>
 