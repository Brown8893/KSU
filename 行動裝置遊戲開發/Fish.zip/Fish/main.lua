local fish_life = 100   -- 房子可承受的打擊分數
local asteroidsTable = {}
local dirx = {}
local diry = {}
local physics = require("physics")  -- 物理力作用下移動
physics.start() -- 函數開始物理模擬

-- 顯示背景
-- display.newImageRect( filename, width, height )  ~顯示背景
local bg = display.newImageRect("bg02.jpg", 360, 580)  -- 屏幕上顯示圖像
bg.x = display.contentCenterX   -- 設定背景根據銀幕內的寬度
bg.y = display.contentCenterY   -- 設定背景根據銀幕內的高度

-- 顯示目前有隻魚
-- display.newText( text, x, y, fontsize )  ~顯示文字
local show_bomp = display.newText(0, 60, 20, native.systemFont, 40)   -- 建立文字
local show_hou = display.newText(fish_life, 250, 20, native.systemFont, 40)

-- 捕魚器
local hou = display.newImageRect("fish_net.png", 100, 100)
hou.myName = "House"
-- physics.addBody( object, [bodyType,] [params] )
physics.addBody(hou, "static")  -- 設定房子靜態static，動態則為dynamic
hou.x = display.contentCenterX  --設定房子寬根據房子本身的寬度
hou.y = display.contentHeight - 30  --設定房子的高度-30px

local function createAsteroid() --產生多個炸彈
  -- bump_num = bump_num + 1
  -- show_bomp.text = #asteroidsTable    -- 顯示炸彈數量
  local indx = math.random(1,15)
  local picname = "a11.png"
  if indx > 5 and indx <= 7 then picname = "a12.png" end
  if indx > 7 and indx <=15 then picname = "a13.png" end
  local newAsteroid = display.newImageRect(picname, 80, 80)
  table.insert(asteroidsTable, newAsteroid)
  table.insert(dirx, 2)   
  table.insert(diry, 3)
  -- physics.addBody(newAsteroid, "dynamic", {radius=40, bounce=0.8})   -- 將炸彈圖像加載並放置
  newAsteroid.myName = picname   -- 當檢測到碰撞時，知道該物體是炸彈
  
  newAsteroid.x = math.random(0,300)
  newAsteroid.y = 50
  -- newAsteroid:setLinearVelocity(math.random(40,120), math.random(20,60))  -- 加速度
  -- newAsteroid:applyTorque(math.random(-6,6))  -- 施加隨機量的扭矩(旋轉力)
end

local function gameLoop()
  if (#asteroidsTable < 15) then
    createAsteroid()
  end
end
-- timer.performWithDelay( delay, listener [, iterations] [, tag] )
gameLoopTimer = timer.performWithDelay(1000, gameLoop, 0)   

local function moveBalls(event)
  for i = #asteroidsTable, 1, -1 do
    local thisAsteroid = asteroidsTable[i]
    --local tmpX = thisAsteroid.x
    --local tmpY = thisAsteroid.y
    local dx = dirx[i]
    local dy = diry[i]
    if (thisAsteroid.x > display.contentWidth or thisAsteroid.x < 5) then
      dx = dx * (-1)
      dirx[i] = dx
    end
    if (thisAsteroid.y > display.contentHeight or thisAsteroid.y < 5) then
      dy = dy * (-1)
      diry[i] = dy
    end
    thisAsteroid:translate(dx,dy)
    --if (thisAsteroid.x < -100 or
    --  thisAsteroid.x > display.contentWidth + 100 or
    --  thisAsteroid.y < -100 or
    --  thisAsteroid.y > display.contentHeight + 100)
    --then
    --  display.remove(thisAsteroid)
    --  table.remove(asteroidsTable, i)
    --end
  end
end

Runtime:addEventListener("enterFrame", moveBalls)