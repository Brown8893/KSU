application =
{
	content =
	{
		width = 768,
		height = 1024,
		scale = "zoomEven",
		fps = 60,
	},
}