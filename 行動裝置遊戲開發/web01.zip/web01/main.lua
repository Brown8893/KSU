local showText

local start = display.newImageRect("start.png", 100, 100)
start.x = display.contentCenterX
start.y = display.contentHeight - 25

showText = display.newText("訊息",display.contentCenterX, 80, native.systemFontBold, 30)

local function changePos(posX, posY)
  local tmpy = tonumber(posY)
  start.y = tmpy
end

-- Network ----------------
local function networkListener(event)
  if (event.isError) then
    showText.text = "ERROR: " .. event.response
  else
    showText.text = "System Response: " .. event.response
    changePos(0, event.response)
  end
end

local headers = {}  --send out (post or gets)
headers["Content-Type"] = "application/x-www-form-urlencoded"
headers["Accept-Language"] = "en-US"
local body = "P1=155&P2=366"

local params = {}
params.headers = headers
params.body = body
----------------------------------------

function getData()
  network.request("http://172.20.155.18:8080/123.jsp", "POST", networkListener, params)
end
-- start:addEventListener("tap", getData)
runTime = timer.performWithDelay(500, getData, 0)